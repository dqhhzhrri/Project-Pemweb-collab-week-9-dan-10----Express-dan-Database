# Products API (Week 10)

pada pertemuan week 10 ini kami mempelajari mengenai `Tugas Express x Database` pada pertemuan hari kami juga diberikan tugas untuk melanjutkan REST API produk pada pertemuan  Week-9 kemarin. Dimana penyimpanan array dalam memori diganti dengan PostgreSQL melalui Prisma ORM, sehingga data tetap tersedia setelah Express dijalankan ulang.

## Persiapan

1. Pasang Node.js LTS dan PostgreSQL. Buat database kosong bernama `products_db` (misalnya dari pgAdmin atau `createdb products_db`).
2. Buka terminal pada folder proyek Week-10 dan pasang dependensi:

   ```bash
   npm install
   ```

3. Salin `.env.example` menjadi `.env`, lalu sesuaikan username, password, host, port, dan nama database pada `DATABASE_URL`. Contoh lokal:

   ```env
   DATABASE_URL="postgresql://postgres:password@localhost:5432/products_db?schema=public"
   PORT=3000
   ```

   Jangan unggah `.env` ke repositori karena berisi kredensial.

## Membuat tabel dan menjalankan server

4. Buat Prisma Client dan migrasi tabel ke PostgreSQL:

   ```bash
   npm run db:generate
   npm run db:migrate -- --name init
   ```

5. Jalankan API:

   ```bash
   npm start
   ```

   Server tersedia di `http://localhost:3000`. Untuk pengembangan, gunakan `npm run dev`.

## Endpoint

Semua endpoint memakai prefix `/products`. Request body JSON untuk POST dan PUT harus berisi `name` string tidak kosong dan `price` angka non-negatif.

| Method | Path | Fungsi | Berhasil |
|---|---|---|---|
| GET | `/products` | Semua produk | 200 |
| GET | `/products/:id` | Satu produk | 200 |
| POST | `/products` | Tambah produk | 201 |
| PUT | `/products/:id` | Ganti nama dan harga produk | 200 |
| DELETE | `/products/:id` | Hapus produk | 200 |

Produk tidak ditemukan menghasilkan 404 dengan `{"message":"Produk tidak ditemukan"}`. Input tidak valid menghasilkan 400.

## Uji manual dan cek persistensi

6. Dengan server aktif, tambahkan produk:

   ```bash
   curl -X POST http://localhost:3000/products -H "Content-Type: application/json" -d "{\"name\":\"Pensil\",\"price\":3000}"
   ```

   Catat `id` pada respons. Lihat semua produk dan detailnya:

   ```bash
   curl http://localhost:3000/products
   curl http://localhost:3000/products/ID
   ```

7. Uji perubahan data dengan mengganti `ID` menggunakan ID hasil POST:

   ```bash
   curl -X PUT http://localhost:3000/products/ID -H "Content-Type: application/json" -d "{\"name\":\"Pensil 2B\",\"price\":3500}"
   curl -X DELETE http://localhost:3000/products/ID
   ```

   Jalankan POST ulang dengan produk lain sebelum menguji persistensi agar data tetap ada.

8. Hentikan server dengan `Ctrl+C`, lalu jalankan lagi menggunakan `npm start`. Panggil `GET /products` kembali. Produk yang dibuat harus tetap muncul karena tersimpan di PostgreSQL.

9. Buka terminal kedua dan jalankan Prisma Studio:

   ```bash
   npm run db:studio
   ```

   Buka alamat yang ditampilkan (umumnya `http://localhost:5555`) dan pilih model `Product` untuk melihat record pada database.

## Bukti dan laporan

Catat hasil aktual, tanggal, ID produk, status HTTP, hasil GET setelah restart, dan pemeriksaan Prisma Studio pada [`bukti-pengujian/hasil-pengujian.md`](bukti-pengujian/hasil-pengujian.md). Simpan tangkapan layar POST, GET setelah restart, dan tabel Prisma Studio di `bukti-pengujian/Dokumentasi/`. Ganti placeholder tautan repositori di laporan setelah proyek di-push ke Git hosting; tautan tidak dapat dibuat sebelum ada remote/repo yang disediakan.

## Struktur dan alur

`src/server.js` memasang middleware JSON dan router. Router meneruskan request ke controller. Controller memvalidasi input lalu menjalankan operasi Prisma terhadap model `Product` pada `prisma/schema.prisma`. Migrasi disimpan di `prisma/migrations/` setelah perintah migrate dijalankan.
