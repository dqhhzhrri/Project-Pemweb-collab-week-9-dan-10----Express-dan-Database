# Laporan Pengujian Products API Week-10

- Tanggal pengujian: **[isi tanggal saat pengujian]**
- Lingkungan: **[versi Node.js, PostgreSQL, OS]**
- Tautan repositori: **[tempel URL repo setelah proyek dipush]**
- Database: `products_db`

## Prosedur dan hasil

| Skenario | Langkah | Hasil aktual |
|---|---|---|
| Tambah produk | POST `/products` dengan `{"name":"Pensil","price":3000}` | **Belum dijalankan di lingkungan ini.** Isi status, response, serta ID setelah uji lokal. |
| Baca semua produk | GET `/products` | **Belum dijalankan.** Catat status dan response. |
| Baca detail | GET `/products/{id}` | **Belum dijalankan.** Catat status dan response. |
| Ubah produk | PUT `/products/{id}` dengan nama/harga baru | **Belum dijalankan.** Catat status dan response. |
| Hapus produk | DELETE `/products/{id}` | **Belum dijalankan.** Catat status dan response. |
| Persistensi | POST produk, hentikan dan mulai ulang server, lalu GET `/products` | **Belum dapat diverifikasi** tanpa koneksi PostgreSQL aktif. Saat uji dilakukan, catat apakah produk dengan ID yang sama tetap muncul. |
| Prisma Studio | Jalankan `npm run db:studio`, buka model `Product` | **Belum dapat diverifikasi** tanpa koneksi PostgreSQL aktif. Lampirkan tangkapan layar record. |

## Bukti dokumentasi

Simpan screenshot atau ekspor hasil request pada folder `bukti-pengujian/Dokumentasi/`, minimal mencakup:

1. Respons POST beserta ID produk.
2. GET produk setelah server direstart, menunjukkan ID yang sama.
3. Prisma Studio yang menampilkan row produk tersebut.
4. (Opsional) Respons PUT dan DELETE.

Jangan mengisi hasil uji sebagai berhasil sebelum benar-benar dijalankan. Lengkapi placeholder lalu commit laporan dan bukti ke repositori proyek.
