﻿const products = [
  { id: 1, name: "Buku", price: 15000 },
  { id: 2, name: "Pulpen", price: 5000 },
];

function getAllProducts(_req, res) {
  res.status(200).json(products);
}

function getProductById(req, res) {
  const id = Number(req.params.id);
  const product = products.find((item) => item.id === id);
  if (!Number.isInteger(id) || !product) {
    return res.status(404).json({ message: "Produk tidak ditemukan" });
  }
  return res.status(200).json(product);
}

function createProduct(req, res) {
  const { name, price } = req.body;
  if (typeof name !== "string" || !name.trim() || typeof price !== "number" || !Number.isFinite(price) || price < 0) {
    return res.status(400).json({ message: "name harus berupa teks dan price harus berupa angka non-negatif" });
  }
  const newId = products.reduce((highest, item) => Math.max(highest, item.id), 0) + 1;
  const product = { id: newId, name: name.trim(), price };
  products.push(product);
  return res.status(201).json(product);
}

module.exports = { getAllProducts, getProductById, createProduct };
