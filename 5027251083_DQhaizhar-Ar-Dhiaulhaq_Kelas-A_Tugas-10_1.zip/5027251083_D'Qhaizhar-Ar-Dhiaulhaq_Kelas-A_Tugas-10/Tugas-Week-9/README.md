﻿# Products API (Week 9)

jadi untuk tugas week 9 ini saya disuruh untuk membuat REST API sederhana yang digunakan 
untuk mengelola produk menggunakan Express.js. kemudian, Data disimpan sementara di array dalam memori dan data dikembalikan ke kondisi awal setelah server dimulai ulang.

## Cara Menjalankan

pertama-tama pastikan Node.js dan npm tersedia, lalu jalankan dari folder proyek:

```bash
npm install
npm start
```

Kemudian buka Server berjalan di `http://localhost:3000`. Untuk mengganti port, atur environment variable `PORT`.

## Endpoint/ Parameter

| Method | Path | Deskripsi | Status sukses |
|---|---|---|---|
| GET | `/products` | Mengambil semua produk | 200 |
| GET | `/products/id` | Mengambil produk berdasarkan ID | 200 |
| POST | `/products` | Menambahkan produk baru | 201 |

nah disini, untuk roduk yang tidak ada/tidak ditermukan akan menghasilkan `404` dengan JSON `{"message":"Produk tidak ditemukan"}`. POST menerima JSON dengan `name` berupa teks dan `price` berupa angka non-negatif. Input tidak valid menghasilkan `400`.

Contoh request POST: `{"name":"Pensil","price":3000}`

## Alur request–response

`server.js` memasang middleware `express.json()` untuk membaca body JSON, lalu memasang router produk pada `/products`. Router di `routes/productRoutes.js` mencocokkan method dan path lalu memanggil fungsi di `controllers/productController.js`. Controller membaca parameter atau body, mengakses array produk, kemudian mengirim status HTTP dan JSON response.

## Bukti pengujian

Catatan hasil uji tersedia di [`bukti-pengujian/hasil-pengujian.md`](bukti-pengujian/hasil-pengujian.md) dan juga [`bukti-pengujian/Dokumentasi`](bukti-pengujian/Dokumentasi Laporan). kalau mas/pak mau Uji manual bisa dengan menggunakan curl (tapi pastikan sudan melakukan `npm install` dan `npm start` terlebih dahulu yahh..):

```bash
curl http://localhost:3000/products
curl http://localhost:3000/products/1
curl http://localhost:3000/products/999
curl -X POST http://localhost:3000/products -H "Content-Type: application/json" -d "{\"name\":\"Pensil\",\"price\":3000}"
```
