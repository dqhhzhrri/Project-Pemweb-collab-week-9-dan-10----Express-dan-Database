﻿# Bukti Pengujian Endpoint

Tanggal: 1 November 2026

Server berhasil dijalankan dengan `npm start`. kemudian Request HTTP dikirim menggunakan Node.js `fetch` ke `http://localhost:3000`. Semua endpoint mengembalikan status dan JSON yang sesuai.

```text
GET /products | 200 | [{"id":1,"name":"Buku","price":15000},{"id":2,"name":"Pulpen","price":5000},{"id":3,"name":"Pensil","price":3000}]
GET /products/1 | 200 | {"id":1,"name":"Buku","price":15000}
GET /products/999 | 404 | {"message":"Produk tidak ditemukan"}
POST /products | 201 | {"id":4,"name":"Pensil","price":3000}
GET /products after POST | 200 | [{"id":1,"name":"Buku","price":15000},{"id":2,"name":"Pulpen","price":5000},{"id":3,"name":"Pensil","price":3000},{"id":4,"name":"Pensil","price":3000}]
```

di hasil tampilannya, produk ID 3 sudah ada dalam array proses ketika rangkaian uji ini berjalan, sehingga POST menambahkan produk baru dengan ID 4. Data hanya tersimpan di memori selama proses server berjalan.
