const express = require("express");
const productRoutes = require("./routes/productRoutes");
const prisma = require("./db/prisma");
const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());
app.use("/products", productRoutes);
app.use((err, _req, res, _next) => { console.error("Request gagal:", err.message); return res.status(500).json({ message: "Terjadi kesalahan pada server" }); });
const server = app.listen(port, () => console.log(`API berjalan di http://localhost:${port}`));
async function shutdown() { server.close(async () => { await prisma.$disconnect(); process.exit(0); }); }
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
